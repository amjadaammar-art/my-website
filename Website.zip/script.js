/* =============================================
   AMJAD ABU AMMAR — PORTFOLIO SCRIPT
   ============================================= */

(function () {
  'use strict';

  /* ---- NAV scroll state ---- */
  const nav = document.getElementById('nav');
  const onScroll = () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---- Mobile nav toggle ---- */
  const toggle = document.getElementById('navToggle');
  const links  = document.getElementById('navLinks');

  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.classList.toggle('open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  });

  links.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      links.classList.remove('open');
      toggle.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  /* ---- Scroll reveal ---- */
  const revealTargets = [
    '.section-eyebrow',
    '.section-title',
    '.about-text p',
    '.about-stat-cluster',
    '.craft-card',
    '.credit-item',
    '.music-text p',
    '.music-tags',
    '.score-card',
    '.film-logline',
    '.film-info p',
    '.film-credits-list',
    '.film-poster',
    '.project-text p',
    '.contact-text p',
    '.contact-details',
    '.contact-form-wrap',
  ];

  const addReveal = () => {
    document.querySelectorAll(revealTargets.join(',')).forEach((el, i) => {
      el.classList.add('reveal');
      // stagger siblings within same parent
      const siblings = Array.from(el.parentElement.querySelectorAll('.reveal'));
      const sibIndex = siblings.indexOf(el);
      if (sibIndex > 0) {
        el.style.transitionDelay = `${sibIndex * 0.08}s`;
      }
    });
  };

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  addReveal();
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  /* ---- Contact form ---- */
  const form   = document.getElementById('contactForm');
  const notice = document.getElementById('formNotice');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name    = form.name.value.trim();
      const email   = form.email.value.trim();
      const message = form.message.value.trim();

      if (!name || !email || !message) {
        notice.textContent = 'Please fill in your name, email, and message.';
        notice.style.color = '#C0212C';
        return;
      }

      // Simulate submission
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Sending…';
      btn.disabled = true;

      setTimeout(() => {
        notice.textContent = '✓ Message received. Amjad will be in touch soon.';
        notice.style.color = '#B8952A';
        form.reset();
        btn.textContent = 'Send Message';
        btn.disabled = false;
      }, 1200);
    });
  }

  /* ---- Active nav link highlight on scroll ---- */
  const sections = document.querySelectorAll('section[id]');
  const navAs    = document.querySelectorAll('#navLinks a');

  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          navAs.forEach(a => {
            a.style.color = '';
            if (a.getAttribute('href') === `#${entry.target.id}`) {
              a.style.color = 'var(--gold)';
            }
          });
        }
      });
    },
    { threshold: 0.4 }
  );

  sections.forEach(s => sectionObserver.observe(s));

  /* ---- Parallax curtains in hero ---- */
  const curtainL = document.querySelector('.curtain-left');
  const curtainR = document.querySelector('.curtain-right');

  if (curtainL && curtainR) {
    window.addEventListener('mousemove', (e) => {
      const x = e.clientX / window.innerWidth;
      curtainL.style.transform = `translateX(${(x - 0.5) * -18}px)`;
      curtainR.style.transform = `translateX(${(x - 0.5) * 18}px)`;
    }, { passive: true });
  }

  /* ---- Placeholder image generation via canvas ---- */
  const createPlaceholder = (width, height, text, bg, textColor) => {
    const canvas = document.createElement('canvas');
    canvas.width  = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);
    // subtle grid
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let y = 0; y < height; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    // text
    ctx.fillStyle = textColor;
    ctx.font = `300 ${Math.min(width / 12, 24)}px Georgia, serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, width / 2, height / 2);
    return canvas.toDataURL('image/jpeg', 0.9);
  };

  // Swap missing images with placeholders
  document.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', function () {
      const w = this.naturalWidth  || parseInt(this.width)  || 600;
      const h = this.naturalHeight || parseInt(this.height) || 800;
      const label = this.alt || 'Image';

      let bg = '#1A1510';
      let tc = 'rgba(184,149,42,0.6)';
      if (this.classList.contains('about-img')) { bg = '#2A2018'; }

      this.src = createPlaceholder(w || 600, h || 800, label, bg, tc);
      this.style.aspectRatio = '';
    }, { once: true });
  });

})();
